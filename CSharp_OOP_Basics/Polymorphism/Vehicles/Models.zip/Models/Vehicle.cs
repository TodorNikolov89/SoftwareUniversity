﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Vehicles.Models
{
    public abstract class Vehicle
    {
        private double fuelQuantity;
        private double fuelConsumptionInLittersPerkm;

        protected Vehicle(double fuelQuantity, double fuelConsumptionInLittersPerkm)
        {
            this.fuelQuantity = fuelQuantity;
            this.fuelConsumptionInLittersPerkm = fuelConsumptionInLittersPerkm;
        }

        public string Drive(double distance)
        {
            if (this.fuelQuantity >= distance * this.fuelConsumptionInLittersPerkm)
            {
                this.fuelQuantity -= this.fuelConsumptionInLittersPerkm*distance;
                return $"{this.GetType().Name} travelled {distance} km";
            }

            return $"{this.GetType().Name} needs refueling";
        }

        public virtual void Refuel(double fuel)
        {
            this.fuelQuantity += fuel;
        }


        public override string ToString()
        {
            return $"{this.GetType().Name}: {this.fuelQuantity:f2}";
        }
    }
}
