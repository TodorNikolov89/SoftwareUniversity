﻿using System;

namespace DefiningClasses
{
    class StartUp
    {
        static void Main(string[] args)
        {
           

        }
    }
}
