﻿namespace ExtendedDatabase
{
    using System;
    using System.Collections.Generic;
    using System.Text;


    public interface IPerson
    {
        string Name { get; }

        long Id { get; }
    }
}
