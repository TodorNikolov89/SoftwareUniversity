﻿using System;

namespace Database
{
    public class Class1
    {
    }
}
